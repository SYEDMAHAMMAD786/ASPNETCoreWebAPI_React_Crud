﻿using CoreWebAPICRUD.Core.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreWebAPICRUD.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private static List<Student> students = new List<Student>
    {
        new Student { id = 1, stname = "John Doe", course = "cse" },
        new Student { id = 2, stname = "Jane Smith", course = "It" }
    };

        // Gets a list of students
        [HttpGet("List")]
        public IActionResult List()
        {
            return Ok(students);
        }

        // Gets a student by ID
        [HttpGet("Get/{id}")]
        public IActionResult Get(int id)
        {
            var student = students.FirstOrDefault(s => s.id == id);
            if (student == null)
            {
                return NotFound();
            }
            return Ok(student);
        }

        // Creates a new student
        [HttpPost("Create")]
        public IActionResult Create([FromBody] Student student)
        {
            if (student == null)
            {
                return BadRequest("Student data is required.");
            }

            student.id = students.Max(s => s.id) + 1;
            students.Add(student);
            return CreatedAtAction(nameof(Get), new { id = student.id }, student);
        }

        // Updates an existing student by ID
        [HttpPut("Update/{id}")]
        public IActionResult Update(int id, [FromBody] Student student)
        {
            if (student == null || student.id != id)
            {
                return BadRequest("Student data is incorrect.");
            }

            var existingStudent = students.FirstOrDefault(s => s.id == id);
            if (existingStudent == null)
            {
                return NotFound();
            }

            existingStudent.stname = student.stname;
            existingStudent.course = student.course;

            return NoContent();
        }

        // Deletes a student by ID
        [HttpDelete("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            var student = students.FirstOrDefault(s => s.id == id);
            if (student == null)
            {
                return NotFound();
            }

            students.Remove(student);
            return NoContent();
        }
    }

}
