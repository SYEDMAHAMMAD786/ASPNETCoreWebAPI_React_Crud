﻿namespace CoreWebAPICRUD.Core.Interfaces
{
    public interface IStudentRepository
    {
    }
}
