﻿namespace CoreWebAPICRUD.Core.Models
{
    public class Student
    {
        public int id { get; set; }
        public string stname { get; set; }
        public string course { get; set; }
    }
}
