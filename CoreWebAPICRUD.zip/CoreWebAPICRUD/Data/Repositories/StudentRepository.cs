﻿namespace CoreWebAPICRUD.Data.Repositories
{
    public class StudentRepository
    {
    }
}
