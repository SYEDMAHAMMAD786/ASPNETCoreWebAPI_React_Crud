import axios from 'axios';
import { useEffect, useState, useCallback } from 'react';
import '../components/Student.css';

function StudentCrud() {
  const [id, setId] = useState('');
  const [stname, setStname] = useState('');
  const [course, setCourse] = useState('');
  const [students, setStudents] = useState([]);
  const token =  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiYWRtaW4iLCJDdXN0b21DbGFpbSI6IlNvbWVWYWx1ZSIsImV4cCI6MTczMTI0MjQzNywiaXNzIjoiaHR0cHM6Ly9sb2NhbGhvc3Q6NzE2MCIsImF1ZCI6Imh0dHBzOi8vbG9jYWxob3N0OjcxNjAifQ.Q07wFw2sjDKwzBnp7OO_W-kwzXi1MO_rHktO0KOUdhs";

  // Axios instance with Bearer token
  const axiosInstance = axios.create({
    baseURL: 'https://localhost:7160/api/Student',
    headers: {
      'Authorization': `Bearer ${token}`, // Add Bearer token in headers
      'Content-Type': 'application/json',
    }
  });

  // Load students data
  const Load = useCallback(async () => {
    try {
      const result = await axiosInstance.get('/List');
      setStudents(result.data); // Set students list
    } catch (err) {
      console.error('Error loading students:', err);
    }
  }, [token]);

  useEffect(() => {
    Load();
  }, [Load]);

  // Save new student
  async function save(event) {
    event.preventDefault();
    try {
      await axiosInstance.post('/Create', { stname, course });
      alert('Student Registration Successful');
      setId('');
      setStname('');
      setCourse('');
      Load(); // Refresh student list
    } catch (err) {
      alert('Error: ' + err.message);
    }
  }

  // Edit existing student
  function editStudent(student) {
    setId(student.id);
    setStname(student.stname);
    setCourse(student.course);
  }

  // Delete student
  async function deleteStudent(id) {
    try {
      await axiosInstance.delete(`/Delete/${id}`);
      alert('Student deleted successfully');
      Load(); // Refresh student list
    } catch (err) {
      alert('Error: ' + err.message);
    }
  }

  // Update student
  async function update(event) {
    event.preventDefault();
    try {
      await axiosInstance.put(`/Update/${id}`, { id, stname, course });
      alert('Registration Updated');
      setId('');
      setStname('');
      setCourse('');
      Load(); // Refresh student list
    } catch (err) {
      alert('Error: ' + err.message);
    }
  }

  return (
    <div>
      <h1>Student Details</h1>
      <div className="container mt-4">
        <form>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              id="id"
              hidden
              value={id}
              onChange={(event) => setId(event.target.value)}
            />
            <label>Student Name</label>
            <input
              type="text"
              className="form-control"
              id="stname"
              value={stname}
              onChange={(event) => setStname(event.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Course</label>
            <input
              type="text"
              className="form-control"
              id="course"
              value={course}
              onChange={(event) => setCourse(event.target.value)}
            />
          </div>
          <div>
            <button className="btn btn-primary mt-4" onClick={save}>
              Register
            </button>
            <button className="btn btn-warning mt-4" onClick={update}>
              Update
            </button>
          </div>
        </form>
      </div>

      <br />
      <table className="table table-dark" align="center">
        <thead>
          <tr>
            <th scope="col">Student Id</th>
            <th scope="col">Student Name</th>
            <th scope="col">Course</th>
            <th scope="col">Option</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.id}>
              <th scope="row">{student.id}</th>
              <td>{student.stname}</td>
              <td>{student.course}</td>
              <td>
                <button
                  type="button"
                  className="btn btn-warning"
                  onClick={() => editStudent(student)}
                >
                  Edit
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={() => deleteStudent(student.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default StudentCrud;